# RGB-Coloring
Convert RGB color code to Color name
