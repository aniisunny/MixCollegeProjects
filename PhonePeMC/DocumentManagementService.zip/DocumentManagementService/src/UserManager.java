public class UserManager {

    private String userID;
    private String username;
    private String password;

    public UserManager(String userID, String username, String password) {
        this.userID = userID;
        this.username = username;
        this.password = password;
    }
}
